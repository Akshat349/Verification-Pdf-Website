from django.apps import AppConfig

class ProVeriConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pdf_veri'  # ✅ This must match your folder/app name
